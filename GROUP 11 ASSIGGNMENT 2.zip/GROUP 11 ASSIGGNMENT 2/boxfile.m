X=(studentsinMyProgram.CGPA);
boxplot(X);
title('Box plot showing CGPA');
grid on;
