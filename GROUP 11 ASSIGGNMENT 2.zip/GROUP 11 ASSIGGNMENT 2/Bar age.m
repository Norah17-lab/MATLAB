x=(studentsinMyProgram.NAME);
y=(studentsinMyProgram.AGE);
bar(x,y);
title('Students name against Age');
xlabel('Students name');
ylabel('Age');
grid on;

