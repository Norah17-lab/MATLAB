x=(studentsinMyProgram.AGE);
y=(studentsinMyProgram.HEIGHT);
scatter(x,y);
title('Age of student against height');
xlabel('Age of students');
ylabel('Height of students');
grid on;
