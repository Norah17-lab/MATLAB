x=(studentsinMyProgram.NAME);
y=(studentsinMyProgram.AGE);
barh(x,y);
title('Students name against Age');
xlabel('Students name');
ylabel('Age');
grid on;
