x=(studentsinMyProgram.CGPA);
y=exp(x)
semilogx(x,y);
title('Semilogx plot showing CGPA');
grid on;
