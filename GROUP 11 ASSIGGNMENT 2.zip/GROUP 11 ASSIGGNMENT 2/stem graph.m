x=(studentsinMyProgram.CGPA);
y=(studentsinMyProgram.WEIGHT);
stem(x,y);
title('Students CGPA against Weight');
xlabel('Students CGPA');
ylabel('Weight');
grid on;

