x=(studentsinMyProgram.CGPA);
y=(studentsinMyProgram.WEIGHT);
errorbar(x,y);
title('CGPA of student against Weight');
xlabel('CGPA of students');
ylabel('Weight of students');
grid on;
